import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";

/*
 * TEMPORARY localStorage shim for window.storage.
 *
 * The app was written against Claude.ai's artifact storage API
 * (window.storage.get/set/delete/list). That API doesn't exist outside
 * Claude.ai, so this shim re-implements it against the browser's
 * localStorage just so the app runs once deployed.
 *
 * IMPORTANT: localStorage is PER BROWSER, PER DEVICE. It is NOT shared
 * across visitors. That means, with only this shim in place:
 *   - A sender's submission and the admin's moderation queue only live
 *     on the sender's own browser — the site owner won't see it on a
 *     different device.
 *   - A recipient's "received" list only shows messages that were
 *     created in that same browser.
 * In short: this makes the site *run*, not *work* for real multi-person
 * use. Replace this shim with a real backend (Firebase/Supabase) before
 * launching to actual users — see the README for what that involves.
 */
if (!window.storage) {
  const read = () => {
    try {
      return JSON.parse(localStorage.getItem("quietBouquetStore") || "{}");
    } catch {
      return {};
    }
  };
  const write = (data) => localStorage.setItem("quietBouquetStore", JSON.stringify(data));

  window.storage = {
    async get(key, shared = false) {
      const data = read();
      const ns = shared ? "shared" : "personal";
      if (!(ns in data) || !(key in data[ns])) return null;
      return { key, value: data[ns][key], shared };
    },
    async set(key, value, shared = false) {
      const data = read();
      const ns = shared ? "shared" : "personal";
      data[ns] = data[ns] || {};
      data[ns][key] = value;
      write(data);
      return { key, value, shared };
    },
    async delete(key, shared = false) {
      const data = read();
      const ns = shared ? "shared" : "personal";
      const existed = data[ns] && key in data[ns];
      if (data[ns]) delete data[ns][key];
      write(data);
      return { key, deleted: !!existed, shared };
    },
    async list(prefix = "", shared = false) {
      const data = read();
      const ns = shared ? "shared" : "personal";
      const keys = Object.keys(data[ns] || {})
        .filter((k) => k.startsWith(prefix))
        .map((k) => ({ key: k }));
      return { keys, prefix, shared };
    },
  };
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
