import React, { useState, useEffect, useCallback } from "react";

/* ---------------------------------------------------------
   THE QUIET BOUQUET
   An anonymous February messaging site: digibouquets, letters,
   and honest notes — moderated by the site owner before delivery.
   --------------------------------------------------------- */

const ADMIN_PASSCODE = "garden2026"; // demo-only, see note in chat

const FLOWERS = [
  { id: "daisy", name: "Daisy", meaning: "New beginnings", petals: 12, petalLen: 22, petalW: 5, petalColor: "#F3E7DD", centerColor: "#C9A15A", centerR: 9 },
  { id: "lilac", name: "Lilac", meaning: "First love", petals: 10, petalLen: 13, petalW: 6, petalColor: "#B79FD6", centerColor: "#5C3A73", centerR: 6, cluster: true },
  { id: "sunflower", name: "Sunflower", meaning: "Adoration", petals: 14, petalLen: 26, petalW: 6, petalColor: "#E8B84B", centerColor: "#5A3620", centerR: 14 },
  { id: "peony", name: "Peony", meaning: "Romance", petals: 16, petalLen: 20, petalW: 9, petalColor: "#E8879E", centerColor: "#C94F72", centerR: 11, layered: true },
  { id: "carnation", name: "Carnation", meaning: "Fascination", petals: 22, petalLen: 17, petalW: 4, petalColor: "#E85C7A", centerColor: "#9C3A56", centerR: 8 },
  { id: "rose", name: "Rose", meaning: "Love & courage", petals: 10, petalLen: 16, petalW: 10, petalColor: "#C41E3A", centerColor: "#7A0F24", centerR: 9, layered: true },
  { id: "tulip", name: "Tulip", meaning: "Perfect love", petals: 6, petalLen: 24, petalW: 11, petalColor: "#D6486B", centerColor: "#8B2A47", centerR: 7 },
  { id: "lavender", name: "Lavender", meaning: "Devotion & calm", spike: true, petalColor: "#9B7FBF", centerColor: "#6B4E9B" },
  { id: "orchid", name: "Orchid", meaning: "Rare beauty", petals: 5, petalLen: 24, petalW: 12, petalColor: "#D9A6D9", centerColor: "#8B4A8B", centerR: 8 },
  { id: "dahlia", name: "Dahlia", meaning: "Standing strong", petals: 22, petalLen: 19, petalW: 5, petalColor: "#E8724A", centerColor: "#A6431F", centerR: 10, layered: true },
];

const LETTER_TEMPLATES = [
  { label: "A confession", text: "I've wanted to tell you this for a while now, and I finally have the nerve because no one will know it was me...\n\n" },
  { label: "Gratitude", text: "I don't think I've ever properly told you this, so here it is, anonymously:\n\n" },
  { label: "Just because", text: "This isn't a big declaration — I just wanted you to know that today, someone was thinking of you.\n\n" },
  { label: "Blank page", text: "" },
];

/* ---------- storage helpers (best-effort, never throw) ---------- */
async function sGet(key, shared = false) {
  try {
    const r = await window.storage.get(key, shared);
    return r ? r.value : null;
  } catch {
    return null;
  }
}
async function sSet(key, value, shared = false) {
  try {
    return await window.storage.set(key, value, shared);
  } catch {
    return null;
  }
}
async function sList(prefix, shared = false) {
  try {
    const r = await window.storage.list(prefix, shared);
    return r ? r.keys : [];
  } catch {
    return [];
  }
}
async function sDelete(key, shared = false) {
  try {
    return await window.storage.delete(key, shared);
  } catch {
    return null;
  }
}
function uid() {
  return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
}
function codeGen() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

/* ---------- flower illustration ---------- */
function Bloom({ f, size = 64 }) {
  if (f.spike) {
    return (
      <svg viewBox="0 0 100 140" width={size} height={size * 1.3}>
        <line x1="50" y1="140" x2="50" y2="42" stroke="#4A7A4E" strokeWidth="3" />
        {Array.from({ length: 9 }).map((_, i) => {
          const y = 36 + i * 8;
          const w = 15 - i * 0.9;
          return <ellipse key={i} cx="50" cy={y} rx={w / 2} ry="5.5" fill={f.petalColor} opacity={0.95 - i * 0.03} />;
        })}
      </svg>
    );
  }
  const count = f.cluster ? Math.ceil(f.petals / 2) : f.petals;
  const rings = f.layered ? [{ scale: 1, rot: 0 }, { scale: 0.6, rot: 180 / count }] : [{ scale: 1, rot: 0 }];
  return (
    <svg viewBox="0 0 100 100" width={size} height={size}>
      <line x1="50" y1="98" x2="50" y2="66" stroke="#4A7A4E" strokeWidth="2.5" />
      {rings.map((ring, ri) => (
        <g key={ri}>
          {Array.from({ length: count }).map((_, i) => {
            const angle = (360 / count) * i + ring.rot;
            const len = f.petalLen * ring.scale;
            const w = f.petalW * ring.scale;
            return (
              <ellipse
                key={i}
                cx="50"
                cy={50 - len / 1.6}
                rx={w / 2}
                ry={len / 2}
                fill={f.petalColor}
                opacity={0.95}
                transform={`rotate(${angle} 50 50)`}
              />
            );
          })}
        </g>
      ))}
      <circle cx="50" cy="50" r={f.centerR} fill={f.centerColor} />
    </svg>
  );
}

function BouquetPreview({ selection }) {
  const entries = Object.entries(selection).filter(([, n]) => n > 0);
  const instances = [];
  entries.forEach(([id, n]) => {
    const f = FLOWERS.find((x) => x.id === id);
    for (let i = 0; i < n; i++) instances.push(f);
  });
  if (instances.length === 0) {
    return (
      <div className="bloomEmpty">
        <svg viewBox="0 0 100 40" width="140" height="56">
          <path d="M10 35 Q50 5 90 35" fill="none" stroke="#6B4E58" strokeWidth="2" strokeDasharray="3 4" />
        </svg>
        <p>Choose a few blooms below to build the bouquet.</p>
      </div>
    );
  }
  return (
    <div className="bouquetWrap">
      <div className="bouquetFan">
        {instances.slice(0, 16).map((f, i) => {
          const mid = (instances.length - 1) / 2;
          const offset = i - mid;
          return (
            <div
              key={i}
              className="bloomInstance"
              style={{ transform: `rotate(${offset * 6}deg) translateY(${Math.abs(offset) * 3}px)`, zIndex: 100 - Math.abs(offset) }}
            >
              <Bloom f={f} size={56} />
            </div>
          );
        })}
      </div>
      <svg viewBox="0 0 160 26" width="180" className="ribbon">
        <path d="M5 6 Q80 26 155 6" fill="none" stroke="#C9A15A" strokeWidth="4" strokeLinecap="round" />
      </svg>
    </div>
  );
}

/* ---------- small UI atoms ---------- */
function Toast({ toast }) {
  if (!toast) return null;
  return <div className={`toast ${toast.type}`}>{toast.text}</div>;
}
function Field({ label, hint, children }) {
  return (
    <label className="field">
      <span className="fieldLabel">{label}</span>
      {children}
      {hint && <span className="fieldHint">{hint}</span>}
    </label>
  );
}

/* =========================================================
   MAIN APP
   ========================================================= */
export default function App() {
  const [view, setView] = useState("home");
  const [session, setSession] = useState(null);
  const [showSignIn, setShowSignIn] = useState(false);
  const [toast, setToast] = useState(null);
  const [settings, setSettings] = useState({ siteOpen: true, announcement: "", flowersEnabled: FLOWERS.map((f) => f.id) });
  const [settingsLoaded, setSettingsLoaded] = useState(false);

  const flash = useCallback((text, type = "ok") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3200);
  }, []);

  useEffect(() => {
    (async () => {
      const s = await sGet("session", false);
      if (s) {
        try {
          setSession(JSON.parse(s));
        } catch {}
      }
      const settingsRaw = await sGet("settings", true);
      if (settingsRaw) {
        try {
          setSettings((prev) => ({ ...prev, ...JSON.parse(settingsRaw) }));
        } catch {}
      }
      setSettingsLoaded(true);
    })();
  }, []);

  async function persistSettings(next) {
    setSettings(next);
    await sSet("settings", JSON.stringify(next), true);
  }

  async function signIn(name, email) {
    const u = { uid: btoa(unescape(encodeURIComponent(email.trim().toLowerCase()))).slice(0, 18), name: name.trim(), email: email.trim() };
    setSession(u);
    await sSet("session", JSON.stringify(u), false);
    setShowSignIn(false);
    flash(`Signed in as ${u.name}`);
  }
  async function signOut() {
    setSession(null);
    await sDelete("session", false);
    flash("Signed out");
  }

  return (
    <div className="app">
      <style>{CSS}</style>
      <Toast toast={toast} />
      <TopNav view={view} setView={setView} session={session} onSignIn={() => setShowSignIn(true)} onSignOut={signOut} />
      {settings.announcement ? <div className="announceBar">{settings.announcement}</div> : null}
      {!settings.siteOpen && view === "send" ? (
        <div className="closedBanner">The garden is closed for new messages right now. Existing recipients can still view what they've received.</div>
      ) : null}

      <main className="main">
        {view === "home" && <Home setView={setView} session={session} onSignIn={() => setShowSignIn(true)} />}
        {view === "send" && (
          <SendFlow
            session={session}
            settings={settings}
            settingsLoaded={settingsLoaded}
            onNeedSignIn={() => setShowSignIn(true)}
            flash={flash}
          />
        )}
        {view === "mylink" && <MyLink session={session} onNeedSignIn={() => setShowSignIn(true)} flash={flash} />}
        {view === "agreement" && <Agreement />}
        {view === "admin" && <Admin settings={settings} persistSettings={persistSettings} flash={flash} />}
      </main>

      <footer className="footer">
        <span>The Quiet Bouquet — anonymous, moderated, February only.</span>
        <button className="linklike" onClick={() => setView("agreement")}>
          Privacy &amp; agreement
        </button>
      </footer>

      {showSignIn && <SignInModal onClose={() => setShowSignIn(false)} onSignIn={signIn} />}
    </div>
  );
}

/* ---------- nav ---------- */
function TopNav({ view, setView, session, onSignIn, onSignOut }) {
  const tabs = [
    { id: "home", label: "Home" },
    { id: "send", label: "Send" },
    { id: "mylink", label: "My link" },
    { id: "agreement", label: "Agreement" },
    { id: "admin", label: "Admin" },
  ];
  return (
    <nav className="nav">
      <div className="brand" onClick={() => setView("home")}>
        <svg viewBox="0 0 40 40" width="26" height="26">
          <line x1="20" y1="38" x2="20" y2="20" stroke="#4A7A4E" strokeWidth="2" />
          <ellipse cx="20" cy="14" rx="6" ry="9" fill="#D46A80" />
          <ellipse cx="20" cy="14" rx="6" ry="9" fill="#C9A15A" opacity="0.4" transform="rotate(45 20 14)" />
        </svg>
        <span>The Quiet Bouquet</span>
      </div>
      <div className="tabs">
        {tabs.map((t) => (
          <button key={t.id} className={`tab ${view === t.id ? "active" : ""}`} onClick={() => setView(t.id)}>
            {t.label}
          </button>
        ))}
      </div>
      <div className="navRight">
        {session ? (
          <>
            <span className="whoami">{session.name}</span>
            <button className="ghostBtn" onClick={onSignOut}>
              Sign out
            </button>
          </>
        ) : (
          <button className="ghostBtn" onClick={onSignIn}>
            Sign in
          </button>
        )}
      </div>
    </nav>
  );
}

/* ---------- sign-in (demo stand-in for Google Sign-In) ---------- */
function SignInModal({ onClose, onSignIn }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  return (
    <div className="modalOverlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h3>Sign in</h3>
        <p className="modalNote">
          This demo uses a name + email stand-in for Google Sign-In. A real deployment would replace this with actual Google OAuth
          on a proper backend.
        </p>
        <Field label="Name">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
        </Field>
        <Field label="Email">
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" type="email" />
        </Field>
        <div className="modalActions">
          <button className="ghostBtn" onClick={onClose}>
            Cancel
          </button>
          <button
            className="goldBtn"
            disabled={!name.trim() || !email.trim()}
            onClick={() => onSignIn(name, email)}
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- home ---------- */
function Home({ setView, session, onSignIn }) {
  return (
    <div className="home">
      <section className="hero">
        <div className="heroText">
          <span className="eyebrow">February · anonymous by design</span>
          <h1>
            Say the thing.
            <br />
            <em>Stay unnamed.</em>
          </h1>
          <p className="lede">
            Build a digital bouquet from ten hand-drawn blooms, write a letter or a short honest note, and send it to someone
            through their private link. Every message is reviewed before it's delivered — nothing harmful reaches anyone.
          </p>
          <div className="heroActions">
            <button className="goldBtn" onClick={() => setView("send")}>
              Send a bouquet or letter
            </button>
            <button
              className="ghostBtn"
              onClick={() => (session ? setView("mylink") : onSignIn())}
            >
              Get my link
            </button>
          </div>
        </div>
        <div className="heroArt">
          <BouquetPreview selection={{ rose: 2, lavender: 1, peony: 1, daisy: 2 }} />
        </div>
      </section>

      <section className="howItWorks">
        <h2>How it works</h2>
        <ol className="steps">
          <li>
            <span className="stepNum">01</span>
            <div>
              <h4>Someone shares their link</h4>
              <p>A recipient signs in and gets a private code. They share it however they like.</p>
            </div>
          </li>
          <li>
            <span className="stepNum">02</span>
            <div>
              <h4>You build something for them</h4>
              <p>Pick from ten flowers, write a letter, or leave a short anonymous note — or all three.</p>
            </div>
          </li>
          <li>
            <span className="stepNum">03</span>
            <div>
              <h4>It's reviewed, not auto-sent</h4>
              <p>Every message sits in a moderation queue first, so nothing hurtful ever reaches the recipient.</p>
            </div>
          </li>
          <li>
            <span className="stepNum">04</span>
            <div>
              <h4>They receive it — anonymously</h4>
              <p>The recipient sees the bouquet and letter, never who sent it.</p>
            </div>
          </li>
        </ol>
      </section>

      <section className="flowerGallery">
        <h2>Ten blooms to choose from</h2>
        <div className="galleryGrid">
          {FLOWERS.map((f) => (
            <div className="galleryItem" key={f.id}>
              <Bloom f={f} size={52} />
              <span className="galleryName">{f.name}</span>
              <span className="galleryMeaning">{f.meaning}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ---------- send flow ---------- */
function SendFlow({ session, settings, settingsLoaded, onNeedSignIn, flash }) {
  const [step, setStep] = useState(1);
  const [code, setCode] = useState("");
  const [recipient, setRecipient] = useState(null); // {alias}
  const [lookupError, setLookupError] = useState("");
  const [includeBouquet, setIncludeBouquet] = useState(true);
  const [includeLetter, setIncludeLetter] = useState(false);
  const [includeNote, setIncludeNote] = useState(false);
  const [flowerSel, setFlowerSel] = useState({});
  const [letterText, setLetterText] = useState("");
  const [noteText, setNoteText] = useState("");
  const [agree, setAgree] = useState(false);
  const [confirmAlias, setConfirmAlias] = useState(false);
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const enabledFlowers = FLOWERS.filter((f) => settings.flowersEnabled.includes(f.id));

  async function lookup() {
    setLookupError("");
    const clean = code.trim().toUpperCase();
    if (!clean) return;
    const raw = await sGet(`recipient:${clean}`, true);
    if (!raw) {
      setLookupError("No recipient found with that code. Double-check it with whoever shared it.");
      return;
    }
    try {
      const rec = JSON.parse(raw);
      if (rec.disabled) {
        setLookupError("This link is no longer accepting messages.");
        return;
      }
      setRecipient({ alias: rec.displayName, code: clean });
      setStep(2);
    } catch {
      setLookupError("Something went wrong reading that link. Try again.");
    }
  }

  function toggleFlower(id, delta) {
    setFlowerSel((prev) => {
      const n = Math.max(0, Math.min(6, (prev[id] || 0) + delta));
      return { ...prev, [id]: n };
    });
  }

  const totalFlowers = Object.values(flowerSel).reduce((a, b) => a + b, 0);
  const canProceedStep2 = includeBouquet || includeLetter || includeNote;
  const canProceedStep3 =
    (!includeBouquet || totalFlowers > 0) &&
    (!includeLetter || letterText.trim().length > 0) &&
    (!includeNote || noteText.trim().length > 0);

  async function submit() {
    setSending(true);
    const id = uid();
    const message = {
      id,
      code: recipient.code,
      type: [includeBouquet && "bouquet", includeLetter && "letter", includeNote && "note"].filter(Boolean).join("+"),
      flowers: includeBouquet ? flowerSel : {},
      letterText: includeLetter ? letterText.trim() : "",
      noteText: includeNote ? noteText.trim() : "",
      status: "pending",
      createdAt: Date.now(),
    };
    await sSet(`msg:${recipient.code}:${id}`, JSON.stringify(message), true);

    const idxRaw = await sGet(`msgindex:${recipient.code}`, true);
    let idxList = [];
    try {
      idxList = idxRaw ? JSON.parse(idxRaw) : [];
    } catch {}
    idxList.push(id);
    await sSet(`msgindex:${recipient.code}`, JSON.stringify(idxList), true);

    const allRaw = await sGet("allmsgs", true);
    let allList = [];
    try {
      allList = allRaw ? JSON.parse(allRaw) : [];
    } catch {}
    allList.push({ code: recipient.code, id });
    await sSet("allmsgs", JSON.stringify(allList), true);

    setSending(false);
    setDone(true);
    flash("Sent for review");
  }

  if (!settingsLoaded) return <div className="loading">Loading…</div>;

  if (done) {
    return (
      <div className="panel narrow center">
        <Bloom f={FLOWERS[5]} size={72} />
        <h2>It's in the queue.</h2>
        <p>
          Your message for <strong>{recipient.alias}</strong> is waiting for review. Once it's approved, it'll appear in their
          inbox — with no trace of who sent it.
        </p>
        <button
          className="goldBtn"
          onClick={() => {
            setDone(false);
            setStep(1);
            setCode("");
            setRecipient(null);
            setFlowerSel({});
            setLetterText("");
            setNoteText("");
            setIncludeBouquet(true);
            setIncludeLetter(false);
            setIncludeNote(false);
            setAgree(false);
            setConfirmAlias(false);
          }}
        >
          Send another
        </button>
      </div>
    );
  }

  return (
    <div className="panel narrow">
      <StepDots step={step} total={4} />

      {step === 1 && (
        <div>
          <h2>Who is this for?</h2>
          <p className="subtle">Enter the private code they shared with you.</p>
          <div className="codeRow">
            <input
              className="codeInput"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="e.g. FL2X9K"
              onKeyDown={(e) => e.key === "Enter" && lookup()}
            />
            <button className="goldBtn" onClick={lookup} disabled={!code.trim()}>
              Find
            </button>
          </div>
          {lookupError && <p className="errorText">{lookupError}</p>}
        </div>
      )}

      {step === 2 && recipient && (
        <div>
          <h2>Sending to {recipient.alias}</h2>
          <p className="subtle">What would you like to include? Choose at least one.</p>
          <div className="checkList">
            <label className="checkRow">
              <input type="checkbox" checked={includeBouquet} onChange={(e) => setIncludeBouquet(e.target.checked)} />
              <span>A digibouquet</span>
            </label>
            <label className="checkRow">
              <input type="checkbox" checked={includeLetter} onChange={(e) => setIncludeLetter(e.target.checked)} />
              <span>A full letter</span>
            </label>
            <label className="checkRow">
              <input type="checkbox" checked={includeNote} onChange={(e) => setIncludeNote(e.target.checked)} />
              <span>A short honest note (NGL-style, one or two lines)</span>
            </label>
          </div>
          <div className="stepNav">
            <button className="ghostBtn" onClick={() => setStep(1)}>
              Back
            </button>
            <button className="goldBtn" disabled={!canProceedStep2} onClick={() => setStep(3)}>
              Continue
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div>
          <h2>Build it</h2>

          {includeBouquet && (
            <div className="block">
              <h4>Digibouquet</h4>
              <BouquetPreview selection={flowerSel} />
              <div className="flowerPicker">
                {enabledFlowers.map((f) => (
                  <div className="pickerRow" key={f.id}>
                    <Bloom f={f} size={36} />
                    <div className="pickerInfo">
                      <span>{f.name}</span>
                      <small>{f.meaning}</small>
                    </div>
                    <div className="stepper">
                      <button onClick={() => toggleFlower(f.id, -1)}>–</button>
                      <span>{flowerSel[f.id] || 0}</span>
                      <button onClick={() => toggleFlower(f.id, 1)}>+</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {includeLetter && (
            <div className="block">
              <h4>Letter</h4>
              <div className="templateRow">
                {LETTER_TEMPLATES.map((t) => (
                  <button key={t.label} className="chip" onClick={() => setLetterText(t.text)}>
                    {t.label}
                  </button>
                ))}
              </div>
              <textarea
                className="letterArea"
                value={letterText}
                onChange={(e) => setLetterText(e.target.value)}
                placeholder="Write what you want them to know…"
                rows={8}
                maxLength={4000}
              />
              <span className="charCount">{letterText.length}/4000</span>
            </div>
          )}

          {includeNote && (
            <div className="block">
              <h4>Honest note</h4>
              <textarea
                className="noteArea"
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder="Something short and true — the kind of thing you'd only say anonymously."
                rows={3}
                maxLength={280}
              />
              <span className="charCount">{noteText.length}/280</span>
            </div>
          )}

          <div className="stepNav">
            <button className="ghostBtn" onClick={() => setStep(2)}>
              Back
            </button>
            <button className="goldBtn" disabled={!canProceedStep3} onClick={() => setStep(4)}>
              Continue
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div>
          <h2>Review &amp; confirm</h2>
          <div className="reviewCard">
            <p>
              <strong>To:</strong> {recipient.alias}
            </p>
            {includeBouquet && (
              <p>
                <strong>Bouquet:</strong>{" "}
                {Object.entries(flowerSel)
                  .filter(([, n]) => n > 0)
                  .map(([id, n]) => `${n}× ${FLOWERS.find((f) => f.id === id).name}`)
                  .join(", ") || "none selected"}
              </p>
            )}
            {includeLetter && (
              <p>
                <strong>Letter:</strong> {letterText.slice(0, 120)}
                {letterText.length > 120 ? "…" : ""}
              </p>
            )}
            {includeNote && (
              <p>
                <strong>Note:</strong> {noteText}
              </p>
            )}
          </div>

          <label className="checkRow">
            <input type="checkbox" checked={confirmAlias} onChange={(e) => setConfirmAlias(e.target.checked)} />
            <span>
              I've confirmed <strong>{recipient.alias}</strong> is the right person.
            </span>
          </label>
          <label className="checkRow">
            <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            <span>
              I agree to the <a href="#" onClick={(e) => e.preventDefault()}>user agreement</a>: this message is respectful,
              isn't threatening or harassing, and I understand it will be reviewed before delivery and may be removed if it
              violates the guidelines.
            </span>
          </label>

          <div className="stepNav">
            <button className="ghostBtn" onClick={() => setStep(3)}>
              Back
            </button>
            <button className="goldBtn" disabled={!agree || !confirmAlias || sending} onClick={submit}>
              {sending ? "Sending…" : "Send for review"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StepDots({ step, total }) {
  return (
    <div className="stepDots">
      {Array.from({ length: total }).map((_, i) => (
        <span key={i} className={`dot ${i + 1 <= step ? "filled" : ""}`} />
      ))}
    </div>
  );
}

/* ---------- recipient dashboard ---------- */
function MyLink({ session, onNeedSignIn, flash }) {
  const [code, setCode] = useState(null);
  const [alias, setAlias] = useState("");
  const [creating, setCreating] = useState(false);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadMessages = useCallback(async (c) => {
    const idxRaw = await sGet(`msgindex:${c}`, true);
    let ids = [];
    try {
      ids = idxRaw ? JSON.parse(idxRaw) : [];
    } catch {}
    const items = [];
    for (const id of ids) {
      const raw = await sGet(`msg:${c}:${id}`, true);
      if (!raw) continue;
      try {
        const m = JSON.parse(raw);
        if (m.status === "approved") items.push(m);
      } catch {}
    }
    items.sort((a, b) => b.createdAt - a.createdAt);
    setMessages(items);
  }, []);

  useEffect(() => {
    if (!session) {
      setLoading(false);
      return;
    }
    (async () => {
      const c = await sGet(`mycode:${session.uid}`, false);
      if (c) {
        setCode(c);
        await loadMessages(c);
      }
      setLoading(false);
    })();
  }, [session, loadMessages]);

  async function createLink() {
    if (!alias.trim()) return;
    setCreating(true);
    const c = codeGen();
    await sSet(`recipient:${c}`, JSON.stringify({ displayName: alias.trim(), disabled: false, createdAt: Date.now() }), true);
    await sSet(`mycode:${session.uid}`, c, false);
    setCode(c);
    setCreating(false);
    flash("Your link is ready");
  }

  function copyLink() {
    const text = `Send me something anonymously on The Quiet Bouquet — my code: ${code}`;
    navigator.clipboard?.writeText(text);
    flash("Copied to clipboard");
  }

  if (!session) {
    return (
      <div className="panel narrow center">
        <h2>Sign in to get your link</h2>
        <p>Your link is how people find you to send a bouquet, letter, or note.</p>
        <button className="goldBtn" onClick={onNeedSignIn}>
          Sign in
        </button>
      </div>
    );
  }
  if (loading) return <div className="loading">Loading…</div>;

  if (!code) {
    return (
      <div className="panel narrow">
        <h2>Create your link</h2>
        <p className="subtle">
          Pick a display name. This is what senders see to confirm they're sending to you — it doesn't have to be your legal
          name.
        </p>
        <Field label="Display name">
          <input value={alias} onChange={(e) => setAlias(e.target.value)} placeholder="e.g. Jamie" />
        </Field>
        <button className="goldBtn" disabled={!alias.trim() || creating} onClick={createLink}>
          {creating ? "Creating…" : "Create my link"}
        </button>
      </div>
    );
  }

  return (
    <div className="panel wide">
      <h2>Your link</h2>
      <div className="linkBox">
        <span className="linkCode">{code}</span>
        <button className="ghostBtn" onClick={copyLink}>
          Copy share text
        </button>
      </div>
      <p className="subtle">Share this code with people you'd like to hear from. Only approved messages appear below.</p>

      <h3 className="sectionTitle">Received</h3>
      {messages.length === 0 ? (
        <p className="emptyText">Nothing yet. Once someone sends you something and it's approved, it'll show up here.</p>
      ) : (
        <div className="receivedGrid">
          {messages.map((m) => (
            <div className="receivedCard" key={m.id}>
              {Object.values(m.flowers || {}).some((n) => n > 0) && <BouquetPreview selection={m.flowers} />}
              {m.letterText && <p className="letterBody">{m.letterText}</p>}
              {m.noteText && <p className="noteBody">"{m.noteText}"</p>}
              <span className="dateStamp">{new Date(m.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- agreement ---------- */
function Agreement() {
  return (
    <div className="panel wide">
      <h2>User agreement &amp; privacy</h2>
      <div className="agreementBody">
        <h4>Anonymity</h4>
        <p>
          Every message sent through The Quiet Bouquet is anonymous to the recipient. The recipient will never see the
          sender's name, email, or any identifying detail — only the bouquet, letter, or note itself.
        </p>
        <h4>Confidentiality</h4>
        <p>
          Sender identity is visible only to the site owner, for moderation purposes, and is never shared with the recipient
          or any other party. The recipient's identity is limited to the display alias they choose to show senders.
        </p>
        <h4>Moderation</h4>
        <p>
          Every message is held for review before delivery. The site owner may decline to deliver, or later remove, any
          message that is threatening, harassing, hateful, sexually explicit, or otherwise likely to cause harm — even after
          it was initially approved.
        </p>
        <h4>What senders agree to</h4>
        <ul>
          <li>Content must be respectful — no threats, harassment, hate speech, or explicit content.</li>
          <li>Do not impersonate someone else or misuse another person's link without their knowledge.</li>
          <li>The site owner's moderation decisions are final.</li>
        </ul>
        <h4>What recipients should know</h4>
        <ul>
          <li>Anyone with your code can send you something — share it only where you're comfortable.</li>
          <li>You can ask the site owner to disable your link at any time.</li>
          <li>If something delivered to you feels wrong, report it — it can be removed retroactively.</li>
        </ul>
        <h4>Data</h4>
        <p>
          This is a demo build: data lives in shared app storage without production-grade access controls or encryption. Do
          not treat it as secure for sensitive real-world use without a proper backend.
        </p>
      </div>
    </div>
  );
}

/* ---------- admin ---------- */
function Admin({ settings, persistSettings, flash }) {
  const [authed, setAuthed] = useState(false);
  const [pass, setPass] = useState("");
  const [tab, setTab] = useState("pending");
  const [allEntries, setAllEntries] = useState([]);
  const [messagesById, setMessagesById] = useState({});
  const [recipients, setRecipients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filterStatus, setFilterStatus] = useState("all");
  const [search, setSearch] = useState("");
  const [removeReasonFor, setRemoveReasonFor] = useState(null);
  const [reasonText, setReasonText] = useState("");

  const loadAll = useCallback(async () => {
    setLoading(true);
    const allRaw = await sGet("allmsgs", true);
    let list = [];
    try {
      list = allRaw ? JSON.parse(allRaw) : [];
    } catch {}
    const byId = {};
    for (const entry of list) {
      const raw = await sGet(`msg:${entry.code}:${entry.id}`, true);
      if (raw) {
        try {
          byId[`${entry.code}:${entry.id}`] = JSON.parse(raw);
        } catch {}
      }
    }
    setAllEntries(list);
    setMessagesById(byId);

    const recKeys = await sList("recipient:", true);
    const recs = [];
    for (const k of recKeys) {
      const raw = await sGet(k.key || k, true);
      if (raw) {
        try {
          recs.push({ code: (k.key || k).replace("recipient:", ""), ...JSON.parse(raw) });
        } catch {}
      }
    }
    setRecipients(recs);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (authed) loadAll();
  }, [authed, loadAll]);

  async function setStatus(entryKey, status, reason) {
    const [code, id] = entryKey.split(":");
    const msg = messagesById[entryKey];
    if (!msg) return;
    const updated = { ...msg, status, removalReason: reason || msg.removalReason || "" };
    await sSet(`msg:${code}:${id}`, JSON.stringify(updated), true);
    setMessagesById((prev) => ({ ...prev, [entryKey]: updated }));
    flash(status === "approved" ? "Approved" : "Removed");
    setRemoveReasonFor(null);
    setReasonText("");
  }

  async function toggleRecipientDisabled(code, disabled) {
    const raw = await sGet(`recipient:${code}`, true);
    if (!raw) return;
    try {
      const rec = JSON.parse(raw);
      const updated = { ...rec, disabled };
      await sSet(`recipient:${code}`, JSON.stringify(updated), true);
      setRecipients((prev) => prev.map((r) => (r.code === code ? { ...r, disabled } : r)));
      flash(disabled ? "Link disabled" : "Link re-enabled");
    } catch {}
  }

  function toggleFlowerEnabled(id) {
    const has = settings.flowersEnabled.includes(id);
    const next = has ? settings.flowersEnabled.filter((x) => x !== id) : [...settings.flowersEnabled, id];
    persistSettings({ ...settings, flowersEnabled: next });
  }

  if (!authed) {
    return (
      <div className="panel narrow center">
        <h2>Admin access</h2>
        <p className="subtle">This area controls moderation, flowers, and site availability.</p>
        <input
          className="codeInput"
          type="password"
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          placeholder="Passcode"
          onKeyDown={(e) => e.key === "Enter" && pass === ADMIN_PASSCODE && setAuthed(true)}
        />
        <button
          className="goldBtn"
          style={{ marginTop: 12 }}
          onClick={() => (pass === ADMIN_PASSCODE ? setAuthed(true) : flash("Wrong passcode", "err"))}
        >
          Enter
        </button>
        <p className="microNote">Demo passcode is hardcoded in the client — swap for real backend auth before going live.</p>
      </div>
    );
  }

  const pending = allEntries
    .map((e) => ({ key: `${e.code}:${e.id}`, msg: messagesById[`${e.code}:${e.id}`] }))
    .filter((x) => x.msg && x.msg.status === "pending");

  const filtered = allEntries
    .map((e) => ({ key: `${e.code}:${e.id}`, msg: messagesById[`${e.code}:${e.id}`] }))
    .filter((x) => x.msg)
    .filter((x) => filterStatus === "all" || x.msg.status === filterStatus)
    .filter((x) => !search.trim() || x.msg.code.toLowerCase().includes(search.trim().toLowerCase()))
    .sort((a, b) => b.msg.createdAt - a.msg.createdAt);

  return (
    <div className="panel wide">
      <h2>Admin</h2>
      <div className="adminTabs">
        {["pending", "all", "recipients", "settings"].map((t) => (
          <button key={t} className={`tab ${tab === t ? "active" : ""}`} onClick={() => setTab(t)}>
            {t === "pending" ? `Pending (${pending.length})` : t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
        <button className="ghostBtn small" onClick={loadAll}>
          Refresh
        </button>
      </div>

      {loading && <div className="loading">Loading…</div>}

      {!loading && tab === "pending" && (
        <div className="adminList">
          {pending.length === 0 && <p className="emptyText">Nothing waiting on review.</p>}
          {pending.map(({ key, msg }) => (
            <MsgAdminCard key={key} entryKey={key} msg={msg} onApprove={() => setStatus(key, "approved")} onRemove={() => setRemoveReasonFor(key)} />
          ))}
        </div>
      )}

      {!loading && tab === "all" && (
        <div>
          <div className="filterRow">
            <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
              <option value="all">All statuses</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="removed">Removed</option>
            </select>
            <input placeholder="Filter by recipient code" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="adminList">
            {filtered.length === 0 && <p className="emptyText">No messages match.</p>}
            {filtered.map(({ key, msg }) => (
              <MsgAdminCard
                key={key}
                entryKey={key}
                msg={msg}
                onApprove={() => setStatus(key, "approved")}
                onRemove={() => setRemoveReasonFor(key)}
                onRestore={msg.status === "removed" ? () => setStatus(key, "approved") : null}
              />
            ))}
          </div>
        </div>
      )}

      {!loading && tab === "recipients" && (
        <div className="adminList">
          {recipients.length === 0 && <p className="emptyText">No recipients yet.</p>}
          {recipients.map((r) => (
            <div className="recipientRow" key={r.code}>
              <div>
                <strong>{r.displayName}</strong>
                <span className="microNote"> · code {r.code}</span>
              </div>
              <button className={r.disabled ? "goldBtn small" : "dangerBtn small"} onClick={() => toggleRecipientDisabled(r.code, !r.disabled)}>
                {r.disabled ? "Re-enable" : "Disable"}
              </button>
            </div>
          ))}
        </div>
      )}

      {!loading && tab === "settings" && (
        <div className="settingsBlock">
          <label className="checkRow">
            <input
              type="checkbox"
              checked={settings.siteOpen}
              onChange={(e) => persistSettings({ ...settings, siteOpen: e.target.checked })}
            />
            <span>Site is open to new submissions</span>
          </label>

          <Field label="Announcement banner" hint="Shown at the top of every page. Leave blank to hide.">
            <input
              value={settings.announcement}
              onChange={(e) => persistSettings({ ...settings, announcement: e.target.value })}
              placeholder="e.g. Moderation may take up to 24 hours this week"
            />
          </Field>

          <h4 className="sectionTitle">Enabled flowers</h4>
          <div className="flowerToggleGrid">
            {FLOWERS.map((f) => (
              <label className="flowerToggle" key={f.id}>
                <input type="checkbox" checked={settings.flowersEnabled.includes(f.id)} onChange={() => toggleFlowerEnabled(f.id)} />
                <Bloom f={f} size={28} />
                <span>{f.name}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {removeReasonFor && (
        <div className="modalOverlay" onClick={() => setRemoveReasonFor(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Remove message</h3>
            <p className="modalNote">This message will no longer be visible to the recipient.</p>
            <Field label="Reason (kept for your own records)">
              <input value={reasonText} onChange={(e) => setReasonText(e.target.value)} placeholder="e.g. harassing content" />
            </Field>
            <div className="modalActions">
              <button className="ghostBtn" onClick={() => setRemoveReasonFor(null)}>
                Cancel
              </button>
              <button className="dangerBtn" onClick={() => setStatus(removeReasonFor, "removed", reasonText)}>
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MsgAdminCard({ msg, onApprove, onRemove, onRestore }) {
  return (
    <div className="adminCard">
      <div className="adminCardHead">
        <span className={`statusPill ${msg.status}`}>{msg.status}</span>
        <span className="microNote">to {msg.code} · {new Date(msg.createdAt).toLocaleString()}</span>
      </div>
      {Object.values(msg.flowers || {}).some((n) => n > 0) && (
        <p className="adminField">
          <strong>Bouquet:</strong>{" "}
          {Object.entries(msg.flowers)
            .filter(([, n]) => n > 0)
            .map(([id, n]) => `${n}× ${FLOWERS.find((f) => f.id === id)?.name || id}`)
            .join(", ")}
        </p>
      )}
      {msg.letterText && (
        <p className="adminField">
          <strong>Letter:</strong> {msg.letterText}
        </p>
      )}
      {msg.noteText && (
        <p className="adminField">
          <strong>Note:</strong> {msg.noteText}
        </p>
      )}
      {msg.removalReason && (
        <p className="adminField removalReason">
          <strong>Removal reason:</strong> {msg.removalReason}
        </p>
      )}
      <div className="adminCardActions">
        {msg.status !== "approved" && onApprove && (
          <button className="goldBtn small" onClick={onApprove}>
            Approve
          </button>
        )}
        {msg.status !== "removed" && onRemove && (
          <button className="dangerBtn small" onClick={onRemove}>
            Remove
          </button>
        )}
        {onRestore && (
          <button className="ghostBtn small" onClick={onRestore}>
            Restore
          </button>
        )}
      </div>
    </div>
  );
}

/* ---------- styles ---------- */
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Work+Sans:wght@400;500;600&display=swap');

:root {
  --bg: #241019;
  --bg-soft: #2E1420;
  --surface: #3A1B29;
  --surface-2: #45222F;
  --rose: #D46A80;
  --rose-deep: #B8415C;
  --gold: #C9A15A;
  --gold-soft: #E4C88A;
  --cream: #F3E7DD;
  --muted: #B08D9A;
  --danger: #C0524B;
  --line: rgba(243,231,221,0.14);
}

* { box-sizing: border-box; }

.app {
  background: radial-gradient(ellipse at top, var(--bg-soft), var(--bg) 60%);
  min-height: 100%;
  color: var(--cream);
  font-family: 'Work Sans', sans-serif;
  display: flex;
  flex-direction: column;
}

h1, h2, h3, h4 { font-family: 'Cormorant Garamond', serif; font-weight: 600; margin: 0 0 8px; color: var(--cream); }
h1 { font-size: 44px; line-height: 1.1; } 
h2 { font-size: 28px; }
h3 { font-size: 20px; }
h4 { font-size: 17px; color: var(--gold-soft); }
p { line-height: 1.6; color: var(--muted); margin: 0 0 12px; }
em { color: var(--rose); font-style: italic; }

.nav { display: flex; align-items: center; gap: 20px; padding: 16px 28px; border-bottom: 1px solid var(--line); flex-wrap: wrap; }
.brand { display: flex; align-items: center; gap: 8px; cursor: pointer; font-family: 'Cormorant Garamond', serif; font-size: 19px; font-weight: 600; color: var(--cream); }
.tabs { display: flex; gap: 4px; margin-left: 8px; flex: 1; flex-wrap: wrap; }
.tab { background: none; border: none; color: var(--muted); font-family: 'Work Sans', sans-serif; font-size: 14px; padding: 8px 12px; border-radius: 999px; cursor: pointer; transition: all .15s; }
.tab:hover { color: var(--cream); }
.tab.active { background: var(--surface-2); color: var(--gold-soft); }
.navRight { display: flex; align-items: center; gap: 10px; }
.whoami { font-size: 13px; color: var(--muted); }

.announceBar { background: var(--surface-2); color: var(--gold-soft); text-align: center; padding: 8px 16px; font-size: 13px; }
.closedBanner { background: rgba(192,82,75,0.15); color: #E8A6A0; text-align: center; padding: 10px 16px; font-size: 13px; border-bottom: 1px solid rgba(192,82,75,0.3); }

.main { flex: 1; padding: 32px 28px 60px; max-width: 1100px; margin: 0 auto; width: 100%; }

.footer { display: flex; justify-content: space-between; padding: 18px 28px; border-top: 1px solid var(--line); font-size: 12px; color: var(--muted); flex-wrap: wrap; gap: 8px; }
.linklike { background: none; border: none; color: var(--gold-soft); cursor: pointer; font-size: 12px; text-decoration: underline; }

/* buttons */
.goldBtn { background: linear-gradient(180deg, var(--gold-soft), var(--gold)); color: #2A1710; border: none; padding: 12px 22px; border-radius: 999px; font-weight: 600; font-size: 14px; cursor: pointer; font-family: 'Work Sans', sans-serif; transition: transform .12s; }
.goldBtn:hover:not(:disabled) { transform: translateY(-1px); }
.goldBtn:disabled { opacity: 0.4; cursor: not-allowed; }
.goldBtn.small { padding: 7px 14px; font-size: 13px; }
.ghostBtn { background: transparent; border: 1px solid var(--line); color: var(--cream); padding: 11px 20px; border-radius: 999px; cursor: pointer; font-size: 14px; font-family: 'Work Sans', sans-serif; }
.ghostBtn:hover { border-color: var(--gold); color: var(--gold-soft); }
.ghostBtn.small { padding: 6px 13px; font-size: 13px; }
.dangerBtn { background: var(--danger); color: #FFF3F1; border: none; padding: 11px 20px; border-radius: 999px; cursor: pointer; font-size: 14px; }
.dangerBtn.small { padding: 6px 13px; font-size: 13px; }

/* home */
.hero { display: flex; align-items: center; gap: 40px; padding: 20px 0 56px; flex-wrap: wrap; }
.heroText { flex: 1 1 380px; }
.eyebrow { font-size: 12px; letter-spacing: 0.14em; text-transform: uppercase; color: var(--gold); }
.lede { font-size: 15px; max-width: 480px; margin-top: 14px; }
.heroActions { display: flex; gap: 12px; margin-top: 22px; flex-wrap: wrap; }
.heroArt { flex: 1 1 280px; display: flex; justify-content: center; background: var(--surface); border-radius: 20px; padding: 30px; border: 1px solid var(--line); }

.howItWorks { padding: 40px 0; border-top: 1px solid var(--line); }
.steps { list-style: none; margin: 24px 0 0; padding: 0; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap: 22px; }
.steps li { display: flex; gap: 12px; }
.stepNum { font-family: 'Cormorant Garamond', serif; font-size: 22px; color: var(--rose); font-weight: 600; }

.flowerGallery { padding: 40px 0; border-top: 1px solid var(--line); }
.galleryGrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(110px,1fr)); gap: 18px; margin-top: 20px; }
.galleryItem { display: flex; flex-direction: column; align-items: center; text-align: center; background: var(--surface); border-radius: 14px; padding: 16px 8px; border: 1px solid var(--line); }
.galleryName { font-size: 13px; font-weight: 600; margin-top: 6px; color: var(--cream); }
.galleryMeaning { font-size: 11px; color: var(--muted); margin-top: 2px; }

/* panels */
.panel { background: var(--surface); border: 1px solid var(--line); border-radius: 18px; padding: 30px; }
.panel.narrow { max-width: 520px; margin: 0 auto; }
.panel.wide { max-width: 820px; margin: 0 auto; }
.panel.center { text-align: center; display: flex; flex-direction: column; align-items: center; }
.subtle { font-size: 13px; }
.microNote { font-size: 11px; color: var(--muted); margin-top: 10px; }
.emptyText { font-size: 14px; color: var(--muted); }
.loading { text-align: center; padding: 60px; color: var(--muted); }

.field { display: block; margin-bottom: 16px; }
.fieldLabel { display: block; font-size: 12px; color: var(--gold-soft); margin-bottom: 6px; }
.fieldHint { display: block; font-size: 11px; color: var(--muted); margin-top: 4px; }
input, textarea, select { width: 100%; background: var(--bg-soft); border: 1px solid var(--line); color: var(--cream); border-radius: 10px; padding: 11px 13px; font-family: 'Work Sans', sans-serif; font-size: 14px; }
input:focus, textarea:focus, select:focus { outline: none; border-color: var(--gold); }

.codeRow { display: flex; gap: 10px; }
.codeInput { text-transform: uppercase; letter-spacing: 0.08em; font-weight: 600; }
.errorText { color: #E8A6A0; font-size: 13px; margin-top: 10px; }

.checkList { display: flex; flex-direction: column; gap: 10px; margin: 18px 0; }
.checkRow { display: flex; align-items: flex-start; gap: 10px; font-size: 14px; margin-bottom: 12px; cursor: pointer; }
.checkRow input { width: auto; margin-top: 3px; }
.checkRow a { color: var(--gold-soft); }

.stepDots { display: flex; gap: 6px; margin-bottom: 20px; }
.dot { width: 8px; height: 8px; border-radius: 50%; background: var(--line); }
.dot.filled { background: var(--gold); }

.block { margin: 18px 0 26px; padding-top: 18px; border-top: 1px solid var(--line); }
.flowerPicker { display: flex; flex-direction: column; gap: 8px; margin-top: 14px; }
.pickerRow { display: flex; align-items: center; gap: 12px; background: var(--bg-soft); border-radius: 10px; padding: 8px 12px; }
.pickerInfo { flex: 1; display: flex; flex-direction: column; }
.pickerInfo small { color: var(--muted); font-size: 11px; }
.stepper { display: flex; align-items: center; gap: 10px; }
.stepper button { width: 26px; height: 26px; border-radius: 50%; border: 1px solid var(--line); background: var(--surface-2); color: var(--cream); cursor: pointer; font-size: 15px; line-height: 1; }

.templateRow { display: flex; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.chip { background: var(--surface-2); border: 1px solid var(--line); color: var(--gold-soft); border-radius: 999px; padding: 6px 13px; font-size: 12px; cursor: pointer; }
.letterArea, .noteArea { resize: vertical; }
.charCount { display: block; text-align: right; font-size: 11px; color: var(--muted); margin-top: 4px; }

.reviewCard { background: var(--bg-soft); border-radius: 12px; padding: 16px; margin: 16px 0; }
.reviewCard p { color: var(--cream); font-size: 13px; margin-bottom: 8px; }

.stepNav { display: flex; justify-content: space-between; margin-top: 22px; }

/* bouquet */
.bouquetWrap { display: flex; flex-direction: column; align-items: center; }
.bouquetFan { display: flex; align-items: flex-end; justify-content: center; min-height: 90px; }
.bloomInstance { margin: 0 -8px; }
.ribbon { margin-top: -4px; }
.bloomEmpty { text-align: center; color: var(--muted); font-size: 12px; }
.bloomEmpty p { margin-top: 4px; }

/* my link */
.linkBox { display: flex; align-items: center; gap: 14px; background: var(--bg-soft); border-radius: 12px; padding: 14px 18px; margin: 14px 0; }
.linkCode { font-family: 'Cormorant Garamond', serif; font-size: 26px; letter-spacing: 0.12em; color: var(--gold-soft); font-weight: 600; }
.sectionTitle { margin-top: 26px; }
.receivedGrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px,1fr)); gap: 16px; margin-top: 14px; }
.receivedCard { background: var(--bg-soft); border-radius: 14px; padding: 16px; border: 1px solid var(--line); }
.letterBody { font-size: 13px; color: var(--cream); white-space: pre-wrap; }
.noteBody { font-size: 13px; color: var(--rose); font-style: italic; }
.dateStamp { font-size: 11px; color: var(--muted); display: block; margin-top: 8px; }

/* agreement */
.agreementBody ul { margin: 0 0 14px; padding-left: 18px; color: var(--muted); font-size: 14px; }
.agreementBody li { margin-bottom: 6px; }

/* admin */
.adminTabs { display: flex; gap: 6px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; }
.filterRow { display: flex; gap: 10px; margin-bottom: 16px; }
.adminList { display: flex; flex-direction: column; gap: 12px; }
.adminCard { background: var(--bg-soft); border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px; }
.adminCardHead { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 6px; }
.statusPill { font-size: 11px; padding: 3px 10px; border-radius: 999px; text-transform: uppercase; letter-spacing: 0.04em; }
.statusPill.pending { background: rgba(201,161,90,0.2); color: var(--gold-soft); }
.statusPill.approved { background: rgba(125,170,122,0.2); color: #A8D1A5; }
.statusPill.removed { background: rgba(192,82,75,0.2); color: #E8A6A0; }
.adminField { font-size: 13px; color: var(--cream); margin-bottom: 6px; }
.removalReason { color: #E8A6A0; }
.adminCardActions { display: flex; gap: 8px; margin-top: 10px; }
.recipientRow { display: flex; justify-content: space-between; align-items: center; background: var(--bg-soft); border-radius: 10px; padding: 12px 16px; border: 1px solid var(--line); }
.settingsBlock { display: flex; flex-direction: column; gap: 6px; }
.flowerToggleGrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px,1fr)); gap: 12px; margin-top: 12px; }
.flowerToggle { display: flex; flex-direction: column; align-items: center; gap: 4px; background: var(--bg-soft); border-radius: 10px; padding: 10px; font-size: 12px; cursor: pointer; border: 1px solid var(--line); }
.flowerToggle input { width: auto; }

/* modal */
.modalOverlay { position: fixed; inset: 0; background: rgba(20,8,13,0.72); display: flex; align-items: center; justify-content: center; z-index: 50; padding: 20px; }
.modal { background: var(--surface); border: 1px solid var(--line); border-radius: 16px; padding: 26px; max-width: 400px; width: 100%; }
.modalNote { font-size: 12px; }
.modalActions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }

/* toast */
.toast { position: fixed; top: 16px; right: 16px; background: var(--surface-2); border: 1px solid var(--gold); color: var(--cream); padding: 10px 18px; border-radius: 10px; font-size: 13px; z-index: 100; }
.toast.err { border-color: var(--danger); }

@media (max-width: 640px) {
  h1 { font-size: 32px; }
  .nav { padding: 12px 16px; }
  .main { padding: 20px 16px 50px; }
}
`;
